package com.droidquest.materials;

import java.awt.Color;

public class Monitor extends Material {
    public Monitor() {
        super(Color.red, true, false);
    }

}
