package com.droidquest.items;


public class Initializer extends Item {
    protected Initializer() {
        width = 0;
        height = 0;
        x = 0;
        y = 0;
        room = null;
    }

    public void Init() {
    }

}