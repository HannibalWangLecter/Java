package com.droidquest.materials;

import java.awt.Color;

public class ChipTester extends Material {
    public ChipTester() {
        color = Color.black;
        passable = true;
    }
}